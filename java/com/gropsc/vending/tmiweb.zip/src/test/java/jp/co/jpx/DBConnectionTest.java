package jp.co.jpx;

import java.sql.Connection;
import java.sql.DriverManager;

import org.junit.jupiter.api.Test;

/**
 * DBconnection　テストクラス
 */
public class DBConnectionTest {


	private static final String URL ="jdbc:postgresql://ec2-3-230-106-126.compute-1.amazonaws.com:5432/dda0jtbs40q641";
	private static final String USER = "jdzosxrwhiiajc";
	private static final String PASSWORD = "7d7d2a659981f1df768e74722825a9bdcc100b0a296d5d36e1d77f8400b9b16d";


	@Test
	public void test() {
		try(Connection con = DriverManager.getConnection(URL, USER, PASSWORD)){
			System.out.println(con);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
