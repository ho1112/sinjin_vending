package jp.co.jpx.util;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class SessionManagerListener implements HttpSessionListener {

	@Override
	public void sessionCreated(HttpSessionEvent se) {
		//se.getSession().setMaxInactiveInterval(5); //実際は5->1分ぐらいになった。
		//session TimeOut 60m 60*60
		System.out.println("session created");
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		System.out.println(se.hashCode()+" : shutDown!!!");
	}





}
