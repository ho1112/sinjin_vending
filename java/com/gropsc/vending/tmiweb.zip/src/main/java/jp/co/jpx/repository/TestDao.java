package jp.co.jpx.repository;

import org.springframework.stereotype.Repository;

@Repository
public class TestDao {


}
