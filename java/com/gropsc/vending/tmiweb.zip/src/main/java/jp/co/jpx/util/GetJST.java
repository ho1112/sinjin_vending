package jp.co.jpx.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class GetJST {

	public Date getJST() {
	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
	    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
	    SimpleDateFormat localDateFormat = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");

	    Date UTCtoJST = null;
	    try {
			UTCtoJST = localDateFormat.parse( simpleDateFormat.format(new Date()) );
		} catch (ParseException e) {
			e.printStackTrace();
		}

	    System.out.println("UTC : "+UTCtoJST);
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(UTCtoJST);
	    calendar.add(Calendar.HOUR_OF_DAY,9);
	    UTCtoJST = calendar.getTime();
	    System.out.println("JST : "+UTCtoJST);

	    return UTCtoJST;
	}
}
