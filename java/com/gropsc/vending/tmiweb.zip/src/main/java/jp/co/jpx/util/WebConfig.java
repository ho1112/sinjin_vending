package jp.co.jpx.util;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 *　インターセプターの設定クラス
 * WebConfig.java -> Interceptor.java
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new Interceptor())
				.addPathPatterns("/*")
				//TOP画面とエラー画面は対象外 (excludePathPatterns)
				//.excludePathPatterns("/")
				.excludePathPatterns("/ERROR")
				.excludePathPatterns("/TempLogin");
	}

}
