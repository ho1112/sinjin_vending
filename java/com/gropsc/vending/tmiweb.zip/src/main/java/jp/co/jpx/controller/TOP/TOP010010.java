package jp.co.jpx.controller.TOP;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.JsonNode;

import jp.co.jpx.util.RestAPIService;

/**
 * 共通MenuのControllerクラス
 * 各メニュー画面に遷移させる。
 */
@RestController
public class TOP010010 {

	//API呼び出しクラス
	@Autowired
	private RestAPIService restAPI;

    @Autowired
    LocaleResolver localeResolver;


	//top画面ID
	private static final String TOP010010 = "TOP/TOP010010";
	private static final String TOP020010 = "TOP/TOP020010";


	/**
	 * top画面を表示
	 * @return 東証からのお知らせ
	 */
	@RequestMapping(value = "/TOP010010")
	public ModelAndView top(ModelAndView mv, HttpServletRequest request, HttpServletResponse response, String language) {
		//言語をsessionに保存
		localeResolver.setLocale( request, response, Locale.JAPANESE );
		mv.setViewName(TOP010010);
		String userAgent = request.getHeader("User-Agent");
		System.out.println(userAgent);

		//メニューボタンを選択状態に変更する設定値
		mv.addObject("currentMenu", "TOP");
		//API呼び出し
		String apiKey = "top010010";
		JsonNode data = restAPI.RestAPIConnection(apiKey);

		//List<TopItem> dataList = new ArrayList<TopItem>();
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		for(int i = 0; i < data.size(); i++) {
			// .path("data0")も使える、ない場合MissingNodeを返却
			for(int j = 0; j < data.get(i).get("固有情報部").size(); j++) {
				/*
				 * 1. API-> DTO object-> List return
				TopItem res = new TopItem();
				res.setDate(data.get(i).get("固有情報部").get(j).get("更新日時").asText());
				res.setNews(data.get(i).get("固有情報部").get(j).get("お知らせ").asText());
				*/
				// 2. API-> Map-> List return
				Map<String, String> res = new HashMap<String, String>();
				res.put("date", data.get(i).get("固有情報部").get(j).get("更新日時").asText());
				res.put("news", data.get(i).get("固有情報部").get(j).get("お知らせ").asText());
				dataList.add(res);
			}
		}

		mv.addObject("dataList", dataList);
		return mv;
	}

	/**
	 * top画面を表示
	 * @return 東証からのお知らせ
	 */
	@RequestMapping(value = "/TOP020010")
	public ModelAndView top_en(ModelAndView mv, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		//言語をsessionに保存
		localeResolver.setLocale( request, response, Locale.ENGLISH );
		/** 言語取得テスト **/
		/*
		Locale locale = ( Locale )session
                .getAttribute( SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME );
		System.out.println("選択言語: "+locale.getLanguage());
		 */
		/** 言語取得テスト **/
		//画面名を指定
		mv.setViewName(TOP020010);
		//メニューボタンを選択状態に変更する設定値
		mv.addObject("currentMenu", "TOP");
		//API呼び出し
		String apiKey = "top010010";
		JsonNode data = restAPI.RestAPIConnection(apiKey);

		//List<TopItem> dataList = new ArrayList<TopItem>();
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		for(int i = 0; i < data.size(); i++) {
			// .path("data0")も使える、ない場合MissingNodeを返却
			for(int j = 0; j < data.get(i).get("固有情報部").size(); j++) {
				/*
				 * 1. API-> DTO object-> List return
				TopItem res = new TopItem();
				res.setDate(data.get(i).get("固有情報部").get(j).get("更新日時").asText());
				res.setNews(data.get(i).get("固有情報部").get(j).get("お知らせ").asText());
				*/
				// 2. API-> Map-> List return
				Map<String, String> res = new HashMap<String, String>();
				res.put("date", data.get(i).get("固有情報部").get(j).get("更新日時").asText());
				res.put("news", data.get(i).get("固有情報部").get(j).get("お知らせ").asText());
				dataList.add(res);
			}
		}

		mv.addObject("dataList", dataList);
		return mv;
	}




}
