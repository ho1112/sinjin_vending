package jp.co.jpx.controller.TPX;

import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import jp.co.jpx.util.GetJST;

@RestController
public class TPXCommon {

	/** TPXヘッダー
	 * 1:当日情報 2:指数終値・配当込指数終値　3:指数用株式数等変更 4:指数マスタ
	 */
	private static final String TPX_MENU_1 = "tpx-menu-1";
	private static final String TPX_MENU_2 = "tpx-menu-2";
	private static final String TPX_MENU_3 = "tpx-menu-3";
	private static final String TPX_MENU_4 = "tpx-menu-4";

	/**
	 * TOPIX基礎情報画面を表示
	 * @return　TOPIX基礎情報画面
	 */
	@RequestMapping(value = "/TPX010010", method = RequestMethod.POST)
	public ModelAndView topix(ModelAndView mv, HttpSession session) {

		/** 言語取得テスト **/
		Locale locale = ( Locale )session
                .getAttribute( SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME );
		System.out.println("選択言語: "+locale.getLanguage());
		/** 言語取得テスト **/

		//画面名を指定
		mv.setViewName("TPX/TPX010010");
		//メニューボタンを選択状態に変更する設定値
		mv.addObject("currentMenu", "TPX");
		//TPXヘッダーボタン選択状態に変更する設定値
		//1:当日情報 2:指数終値・配当込指数終値　3:指数用株式数等変更 4:指数マスタ
		mv.addObject("currentTPX",TPX_MENU_1);
		return mv;
	}

	/**
	 * 指数終値・配当込指数終値画面を表示
	 * @return 指数終値・配当込指数終値
	 */
	@RequestMapping(value = "/TPX010020", method = RequestMethod.POST)
	public String TPX010020(ModelAndView mv) {
		//画面名を指定
		//mv.setViewName("TPX/TPX010020");
		//メニューボタンを選択状態に変更する設定値
		mv.addObject("currentMenu", "TPX");
		//TPXヘッダーボタン選択状態に変更する設定値
		//1:当日情報 2:指数終値・配当込指数終値　3:指数用株式数等変更 4:指数マスタ
		mv.addObject("currentTPX",TPX_MENU_2);
		return "/TPX/TPX010020";
	}

	/**
	 * 指数用株式数等変更検索画面を表示
	 * @return 指数用株式数等変更検索
	 */
	@RequestMapping(value = "/TPX010030", method = RequestMethod.POST)
	public ModelAndView TPX010030(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("TPX/TPX010030");
		//メニューボタンを選択状態に変更する設定値
		mv.addObject("currentMenu", "TPX");
		//TPXヘッダーボタン選択状態に変更する設定値
		mv.addObject("currentTPX",TPX_MENU_3);
		return mv;
	}

	/**
	 * 指数マスタ画面を表示
	 * @return 指数マスタ
	 */
	@RequestMapping(value = "/TPX010080", method = RequestMethod.POST)
	public ModelAndView TPX010080(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("TPX/TPX010080");
		//メニューボタンを選択状態に変更する設定値
		mv.addObject("currentMenu", "TPX");
		//TPXヘッダーボタン選択状態に変更する設定値
		//1:当日情報 2:指数終値・配当込指数終値　3:指数用株式数等変更 4:指数マスタ
		mv.addObject("currentTPX",TPX_MENU_4);
		return mv;
	}



	@RequestMapping(value = "/getDate", method = RequestMethod.POST)
	public String test(ModelAndView mv) {
		//画面名を指定

		GetJST getJST = new GetJST();
		Date jst = getJST.getJST();
		System.out.println("getDate : "+jst);
		return jst.toString();
	}




}
