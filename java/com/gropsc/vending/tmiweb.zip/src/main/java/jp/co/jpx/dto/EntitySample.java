package jp.co.jpx.dto;

import lombok.Data;

/**
 * Rest API request BODY Object
 */
@Data
public class EntitySample {

	private String ユーザID;
	private String 画面ID;
	private String 遷移元画面ID;
	private String 言語;

}
