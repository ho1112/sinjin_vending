package jp.co.jpx.controller.common;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class Router {

    @Autowired
    LocaleResolver localeResolver;

	/**
	 * 各Controllerに振り分け
	 */
	@RequestMapping(value = "/")
	public ModelAndView controller(ModelAndView mv, HttpServletRequest request, String requestURL) {
		//画面名を指定
		//mv.setViewName("COMMON/TempLogin");
		System.out.println("start router "+request.getRequestURL().toString());

		//String requestURL;
		if(requestURL == null) {
			requestURL = "/TempLogin";
		}
		switch(requestURL) {
		case "TOP010010":
			requestURL = "/TOP010010";
			break;
		case "CAI010010":
			requestURL = "/CAI010010";
			break;
		case "TDN010010":
			requestURL = "/TDN010010";
			break;
		case "TOF010010":
			requestURL = "/TOF010010";
			break;
		case "SGK010010":
			requestURL = "/SGK010010";
			break;
		case "TPX010010":
			requestURL = "/TPX010010";
			break;
		case "CMN010010":
			requestURL = "/CMN010010";
			break;
		case "CMN010130":
			requestURL = "/CMN010130";
			break;
		case "CMN010140":
			requestURL = "/CMN010140";
			break;
		case "CMN010850":
			requestURL = "/CMN010850";
			break;
		case "TPX010020":
			requestURL = "/TPX010020";
			break;
		case "TPX010030":
			requestURL = "/TPX010030";
			break;
		case "TPX010080":
			requestURL = "/TPX010080";
			break;
		case "TPX010040":
			requestURL = "/TPX010040";
			break;
		case "TPX010050":
			requestURL = "/TPX010050";
			break;
		case "getDate":
			requestURL = "/getDate";
			break;
		case "Logout":
			requestURL = "/Logout";
			break;
		case "ERROR":
			requestURL = "/ERROR";
			break;
		default :
			requestURL = "/TempLogin";
			break;
		}
		return new ModelAndView( "forward:"+requestURL );
	}

}
