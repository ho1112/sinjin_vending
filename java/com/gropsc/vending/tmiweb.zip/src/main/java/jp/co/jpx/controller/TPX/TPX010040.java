package jp.co.jpx.controller.TPX;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class TPX010040 {

	/** TPXヘッダー
	 * 1:当日情報 2:指数終値・配当込指数終値　3:指数用株式数等変更 4:指数マスタ
	 */
	private static final String TPX_MENU_3 = "tpx-menu-3";

	@RequestMapping(value = "/TPX010040", method = RequestMethod.POST)
	public ModelAndView test(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("TPX/TPX010040");
		//メニューボタンを選択状態に変更する設定値
		mv.addObject("currentMenu", "TPX");
		//TPXヘッダーボタン選択状態に変更する設定値
		mv.addObject("currentTPX",TPX_MENU_3);

		/*　検索条件FormをSession等に保存しておいて遷移元に戻したとき
		 * 既存の検索条件を設定することを想定して置くこと*/
		return mv;
	}




}
