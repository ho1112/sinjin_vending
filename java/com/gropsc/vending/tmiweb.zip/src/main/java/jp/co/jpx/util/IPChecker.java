package jp.co.jpx.util;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


/**
 * インターセプタークラス用のリクエスト、IPチェックロジックを処理するクラス
 *　@return true:リクエスト許可　/ false:リクエスト禁止
 */
public class IPChecker {

	public static String getClientIp(HttpServletRequest req) {
	    String ip = req.getHeader("X-Forwarded-For");
	    if (ip == null) ip = req.getRemoteAddr();
	    return ip;
	}

	public static boolean ipCheck() {
		boolean result = false;
		HttpServletRequest req = ((ServletRequestAttributes)RequestContextHolder.currentRequestAttributes()).getRequest();
		String ip = getClientIp(req);
		System.out.println("IP : " + ip);
		switch(ip) {
		case "0:0:0:0:0:0:0:1" : //localhost
		case "127.0.0.1" :		 //localhost
		case "172.18.17.134" :
		case "202.32.215.132" :
		case "210.128.234.229" :
		case "210.138.100.138/31" :
		case "211.10.211.39" :
		case "211.10.211.40" :
		case "202.246.251.240/28" :
		case "202.246.252.96/27" :
		case "202.246.252.128/25" :
		case "133.145.228.11" :
		case "133.145.228.13" :
		case "153.165.254.236" :
		case "202.221.220.59" :
			result = true;
			break;
		default :
			break;
		}
		if(!result) {
			return result;
		}

		String URI = req.getRequestURI();
		//GETリクエストは禁止
		String method = req.getMethod();
		if(method.equals("GET") && !(URI.equals("/")) ) {
			result = false;
			return result;
		}


		System.out.println(result+" / "+method+"/ ip: "+ip);

		return result;

	}

}
