package jp.co.jpx.controller.common;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ModelAndView;

import jp.co.jpx.util.DBConnector;

/**
 * 共通MenuのControllerクラス
 * 各メニュー画面に遷移させる。
 */
@RestController
public class Menu {

    @Autowired
    LocaleResolver localeResolver;

	/**
	 * getリクエスト、外部IPは禁止
	 * @return 禁止画面
	 */
	@RequestMapping(value = "/ERROR")
	public ModelAndView get(ModelAndView mv) {
		mv.setViewName("COMMON/GETRequest");
		return mv;
	}

	/**
	 * Login画面
	 * @return Login画面
	 */
	@RequestMapping(value = "/TempLogin")
	public ModelAndView tempLogin(ModelAndView mv) {
		System.out.println("Start TempLogin");
		mv.setViewName("COMMON/TempLogin");
		return mv;
	}

	/**
	 * 言語選択画面
	 * @return 言語選択画面
	 */
	@RequestMapping(value = "/CMN010010")
	public ModelAndView languageSelect(ModelAndView mv, HttpServletRequest req) {
		//画面名を指定
		System.out.println(req.getRequestURL().toString());
		mv.setViewName("COMMON/CMN010010");
		return mv;
	}

	/**
	 * CA情報画面を表示
	 * @return　CA情報画面
	 */
	@RequestMapping(value = "/CAI010010", method = RequestMethod.POST)
	public ModelAndView ca(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("CAI/CAI010010");
		//メニューボタンを選択状態に変更する設定値
		mv.addObject("currentMenu", "CAI");

		/**
		 * DB TEST
		 */
		Connection conn = null;
		Statement stmt = null;
		ResultSet rset = null;
		try {
			conn = DBConnector.getDBConnection();
			//自動コミットOFF
            conn.setAutoCommit(false);
            //SELECT文の実行
            stmt = conn.createStatement();
            String sql = "SELECT * FROM t_pd_jh_tbl where t_kmk_kbn = '210005' or t_kmk_kbn = '210015'";
            rset = stmt.executeQuery(sql);

            while(rset.next()) {
            	String col = rset.getString(1);
            	String col2 = rset.getString(2);
            	String col3 = rset.getString(3);
            	String col4 = rset.getString(4);
            	System.out.println("DB : "+col+"/"+col2+"/"+col3+"/"+col4);
            }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		/**
		 * DB　TEST END
		 */

		return mv;
	}

	/**
	 * TDnetDBS画面を表示
	 * @return　TDnetDBS画面
	 */
	@RequestMapping(value = "/TDN010010", method = RequestMethod.POST)
	public ModelAndView tdnet(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("TDN/TDN010010");
		//メニューボタンを選択状態に変更する設定値
		mv.addObject("currentMenu", "TDN");
		return mv;
	}

	/**
	 * マーケット情報画面を表示
	 * @return　マーケット情報画面
	 */
	@RequestMapping(value = "/TOF010010", method = RequestMethod.POST)
	public ModelAndView market(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("TOF/TOF010010");
		//メニューボタンを選択状態に変更する設定値
		mv.addObject("currentMenu", "TOF");
		return mv;
	}

	/**
	 * 銘柄別総合検索画面を表示
	 * @return　銘柄別総合検索画面
	 */
	@RequestMapping(value = "/SGK010010", method = RequestMethod.POST)
	public ModelAndView search(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("SGK/SGK010010");
		//メニューボタンを選択状態に変更する設定値
		mv.addObject("currentMenu", "SGK");
		return mv;
	}



}
