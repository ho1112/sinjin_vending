package jp.co.jpx.dto;

import java.util.ArrayList;

import lombok.Data;

@Data
public class TopItemObject {

	private String メッセージID;
	private String メッセージ;
	private ArrayList<TopItem> 固有情報部;

}
