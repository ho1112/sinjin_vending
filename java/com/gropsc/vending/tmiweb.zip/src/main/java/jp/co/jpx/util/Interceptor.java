package jp.co.jpx.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;


/**
 * インターセプタークラス
 * リクエストとIPをチェックする。
 *　@return　
 * true:リクエストされたcontrollerで次の作業
 * false:GETリクエスト、外部IPの場合エラー画面を表示
 */
@Component
public class Interceptor implements HandlerInterceptor {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		boolean ipCheckResult = IPChecker.ipCheck();
		//禁止される接近ならエラー画面へ遷移
		if(!ipCheckResult) {
			//エラー画面に遷移
			response.sendRedirect("/ERROR");
			return ipCheckResult;
		}
		return ipCheckResult;
		//return HandlerInterceptor.super.preHandle(request, response, handler);
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO 自動生成されたメソッド・スタブ
		HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO 自動生成されたメソッド・スタブ
		HandlerInterceptor.super.afterCompletion(request, response, handler, ex);
	}


}
