package jp.co.jpx.util;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;

import jp.co.jpx.dto.EntitySample;

@Component
public class RestAPIService {

	//application.propertiesからAPI URLを取得
	@Value("${tmiweb.url}")
	private String apiUrl;

	/**
	 *
	 * @param apiKey、  今後、 request BODYを引数として受ける。
	 * @return APIから取得したJSONデータ
	 */
	public JsonNode RestAPIConnection(String apiKey) {
		//Rest API
		//request url
		String url = apiUrl+apiKey;
		//restTemplate
		RestTemplate restTemplate = new RestTemplate();
		//restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));

		//header
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

		//request BODY(entity)
		/* 1. Map Entity */
		/*
		Map<String, Object> map = new HashMap<>();
		//引数　key : value
		map.put("ユーザID", "API TEST");
		map.put("画面ID", "TOP010010");
		map.put("遷移元画面ID", "TOP010010");
		map.put("言語", "JPN");
		//header map set
		HttpEntity<Map<String, Object>> entity = new HttpEntity<>(map, headers);
		/* 1. Map Entity */

		/* 2. Object Entity */
		EntitySample entityObj = new EntitySample();
		entityObj.setユーザID("API TEST");
		entityObj.set画面ID("TOP010010");
		entityObj.set遷移元画面ID("TOP010010");
		entityObj.set言語("JPN");
		HttpEntity<EntitySample> entity = new HttpEntity<>(entityObj ,headers);
		/* 2. Object Entity */


		//post送信
		JsonNode res = restTemplate.postForObject(url,entity, JsonNode.class);

		return res;
	}


}
