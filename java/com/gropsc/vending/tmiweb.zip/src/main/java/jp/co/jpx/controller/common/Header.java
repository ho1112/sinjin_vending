package jp.co.jpx.controller.common;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.JsonNode;

@RestController
public class Header {

	/**
	 * Logout画面を表示
	 * @return Logout画面
	 */
	@RequestMapping(value = "/Logout")
	public ModelAndView logout(ModelAndView mv, HttpSession session) {
		//画面名を指定
		mv.setViewName("COMMON/CMN010020");

		//sessionを破棄
		session.invalidate();
		return mv;
	}

	/**
	 * Logout画面を表示
	 * @return Logout画面
	 */
	@RequestMapping(value = "/LogoutTest")
	public ModelAndView apiTest(ModelAndView mv) {
		//画面名を指定
		System.out.println("API Start");
		mv.setViewName("COMMON/APITest");
		//Rest API
		//request url
		String url = "https://ph2-api.herokuapp.com/makedata";
		//restTemplate
		RestTemplate restTemplate = new RestTemplate();

		//header
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

		//data用のmap
		Map<String, Object> map = new HashMap<>();
		//引数　key : value
		map.put("data", "API TEST");
		//header map set
		HttpEntity<Map<String, Object>> entity = new HttpEntity<>(map, headers);

		//post送信
		JsonNode res = restTemplate.postForObject(url,entity, JsonNode.class);

		//To java Object - Test java Objectを使うパータン
		//Test resV = new Test();
		/*
		ArrayList testList = new ArrayList<String>();
		for(int i = 0; i < res.size(); i++) {
			// .path("data0")も使える、ない場合MissingNodeを返却
			resV.setData0(res.get(i).get("data0").toString());
			resV.setData1(res.get(i).get("data1").toString());
			resV.setData3(res.get(i).get("data3").toString());
			for(int j = 0; j < res.get(i).get("data2").size(); j++) {
				testList.add(res.get(i).get("data2").get(j));
			}
			resV.setData2(testList);
			testList.clear();
		}
		//To java Object

		System.out.println("API : "+res.get(0).get("data1"));
		System.out.println("Test : "+ resV);
		*/
		mv.addObject("apiVal", res);
		//mv.addObject("testVal", resV);
		return mv;
	}

	/**
	 * ・本サイトのご利用にあｔって画面を表示
	 * @return 本サイトのご利用にあｔって画面
	 */
	@RequestMapping(value = "/CMN010130", method = RequestMethod.POST)
	public ModelAndView terms(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("COMMON/CMN010130");
		return mv;
	}

	/**
	 * ・ご利用の手引き画面を表示
	 * @return ご利用の手引き画面
	 */
	@RequestMapping(value = "/CMN010140", method = RequestMethod.POST)
	public ModelAndView howToUse(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("COMMON/CMN010140");
		return mv;
	}

	/**
	 * ・FAQ画面を表示
	 * @return　FAQ画面
	 */
	@RequestMapping(value = "/CMN010850", method = RequestMethod.POST)
	public ModelAndView FAQ(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("COMMON/CMN010850");
		return mv;
	}


	/**
	 * Logout画面を表示
	 * @return Logout画面
	 */
	@RequestMapping(value = "/Logout_EN")
	public ModelAndView logout_EN(ModelAndView mv, HttpSession session) {
		//画面名を指定
		mv.setViewName("COMMON/CMN020020");

		//sessionを破棄
		session.invalidate();
		return mv;
	}

	/**
	 * ・本サイトのご利用にあｔって画面を表示
	 * @return 本サイトのご利用にあｔって画面
	 */
	@RequestMapping(value = "/CMN020130", method = RequestMethod.POST)
	public ModelAndView terms_EN(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("COMMON/CMN020130");
		return mv;
	}

	/**
	 * ・ご利用の手引き画面を表示
	 * @return ご利用の手引き画面
	 */
	@RequestMapping(value = "/CMN020140", method = RequestMethod.POST)
	public ModelAndView howToUse_EN(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("COMMON/CMN020140");
		return mv;
	}

	/**
	 * ・FAQ画面を表示
	 * @return FAQ画面
	 */
	@RequestMapping(value = "/CMN020850", method = RequestMethod.POST)
	public ModelAndView FAQ_EN(ModelAndView mv) {
		//画面名を指定
		mv.setViewName("COMMON/CMN020850");
		return mv;
	}





}
