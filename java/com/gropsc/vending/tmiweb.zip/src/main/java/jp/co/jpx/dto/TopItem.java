package jp.co.jpx.dto;

import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class TopItem {

	@NotNull(message = "nullの場合出すメッセージ一")
	private String date;
	private String news;


}
