package jp.co.jpx.dto;

import java.util.ArrayList;

import lombok.Data;

@Data
public class TopAPI {

	private ArrayList<TopItemObject> topAPI;
}
