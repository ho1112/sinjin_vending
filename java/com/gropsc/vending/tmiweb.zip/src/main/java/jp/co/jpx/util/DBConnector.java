package jp.co.jpx.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnector {

	private static final String URL ="jdbc:postgresql://ec2-3-230-106-126.compute-1.amazonaws.com:5432/dda0jtbs40q641";
	private static final String USER = "jdzosxrwhiiajc";
	private static final String PASSWORD = "7d7d2a659981f1df768e74722825a9bdcc100b0a296d5d36e1d77f8400b9b16d";


	public static Connection getDBConnection(){
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			return conn;
		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		return null;
	}







}
