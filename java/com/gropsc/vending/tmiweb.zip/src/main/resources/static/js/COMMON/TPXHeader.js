
//画面遷移イベント
function openTPXMenu(event) {
	let viewId = "";
	console.log("test");
	console.log(event);
	switch(event.target.parentNode.id) {
	case "tpx-menu-1" :
		viewId = "/TPX010010";
		break;
	case 'tpx-menu-2' :
		viewId = "/TPX010020";
		break;
	case "tpx-menu-3" :
		viewId = "/TPX010030";
		break;
	case "tpx-menu-4" :
		viewId = "/TPX010080";
		break;
	default :
		return false;
		break;
	}

	const form = document.createElement('form');
	let objs;
	objs = document.createElement('input');
	objs.setAttribute('type', 'hidden');

	//post送信
	form.appendChild(objs);
	form.setAttribute('method', 'post');
	form.setAttribute('action', viewId);
	document.body.appendChild(form);

	form.submit();

}