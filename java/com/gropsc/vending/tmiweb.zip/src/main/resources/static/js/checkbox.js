function Click_Sub1(check) {
    for (i = 0; i < document.all.c1.length; i++) {
        document.all.c1[i].checked = check;
    }
}

function Click_Sub2(check) {
    for (i = 0; i < document.all.c2.length; i++) {
        document.all.c2[i].checked = check;
    }
}

function Click_Sub3(check) {
    for (i = 0; i < document.all.c3.length; i++) {
        document.all.c3[i].checked = check;
    }
}







$(function () {
    $('#checkall').change(function () {
        if ($(this).is(':checked')) {

            $('.heading-title03').find('input').attr('checked', 'checked');
        } else {
            $('.heading-title03').find('input').attr('checked', '');
        }


    })
});
