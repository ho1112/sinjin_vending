window.onload = () => {

	/**
	 * 共通JSファイル初期化を定義
	 */


	document.querySelector(".btJp").addEventListener('click', setParams);
	document.querySelector(".btEn").addEventListener('click', setParams);

}

function setParams(event){
	let url;
	let language;

	//日本語選択
	if(event.target.parentNode.className == "btJp"){
		url = "TOP010010";
		language = "jp"
	//英語選択
	}else {
		url = "TOP020010";
		language = "en";
	}
	//送信データObject
	const params = {
		'language':language,
		'requestURL':"TOP010010"
	};

	postPageRequest(url, params);
}

//画面遷移リクエスト
function postPageRequest(url, params){
	const form = document.createElement('form');
	const objs = document.createElement('input');
	objs.setAttribute('type', 'hidden');
	/*
	//送信したいデータがあったら、inputデータに設定してsetする。
	for(let key in params) {
		objs.setAttribute("name", key);
		objs.setAttribute("value", params[key]);
	}*/
	for(let key in params) {
		objs.setAttribute("name", key);
		objs.setAttribute("value", params[key]);
	}

	//post送信
	form.appendChild(objs);
	form.setAttribute('method', 'post');
	form.setAttribute('action', '/');
	//form.setAttribute("target","_blank");
	document.body.appendChild(form);

	form.submit();
}




























