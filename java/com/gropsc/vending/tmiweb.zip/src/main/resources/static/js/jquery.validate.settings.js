
	String.prototype.startWith = function(str) {
	var reg = new RegExp("^" + str);
	return reg.test(this);
	}
	//测试ok，直接使用str.endWith("abc")方式调用即可  
	String.prototype.endWith = function(str) {
	var reg = new RegExp(str + "$");
	return reg.test(this);
	}


var validator_pattern_message = '@@@@@'

var validator_pattern = { 
	alphanumeric :  {regx : "^[a-zA-Z]+$",   message : "アルファベット(半角)を入力してください。" },
	hiragana : {regx : "^[\u3041-\u3096]+$", message : "ひらがなを入力してください。" },
	katakana : {regx : "^[\u30A1-\u30FA]+$", message : "カタカナ(全角)を入力してください。" },
	email:{regx : "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$", message : "メールアドレスを入力してください。" },
	password:{regx : "^[a-zA-Z0-9]{8,}$", message : "パスワードは半角英数字8桁以上で設定してください" },
	numeric:{regx : "^[0-9]+$", message : "数字(半角)を入力してください。" },
	tel:{regx : "^[0-9/-]+$", message : "正しい電話番号を入力してください。" },
	date:{regx : "^([0-9]{4})/(0[1-9]|1[0-2])/(0[1-9]|[1-2][0-9]|3[0-1])$", message : "正しい日付を入力してください。" },
	kanji:{regx:"^[\u3400-\u9FFF]+$",message:"正しい漢字を入力してください。"}
}

var popoverOption=function (message){
	var option={
                offset: '0, 0',
                placement: 'right',
                container: 'body',
                html: true,
                template:'<div class="popover bg-danger" role="popover" style="border: 0.5px solid transparent;"><div class="arrow error" style="margin-left:10px;"></div><div class="popover-content" style="font-size:11px;margin:4px">'+message+'</div></div>',
              //	template:'<div class="popover" role="popover"><div class="arrow" style=""></div><div class="popover-content" style="font-size:11px;margin:4px">'+message+'</div></div>',
            };
            return option;
}
var promptOption=function (message){
	var option={
                offset: '0, 0',
                placement: 'top',
                container: 'body',
                html: true,
              	template:'<div class="popover bg-info" role="popover" style="border: 0.5px solid transparent;"><div class="arrow prompt" style="margin-left:10px;"></div><div class="popover-content" style="font-size:11px;margin:4px">'+message+'</div></div>',
              //	template:'<div class="popover" role="popover"><div class="arrow" style=""></div><div class="popover-content" style="font-size:11px;margin:4px">'+message+'</div></div>',
            };
            return option;
}

var promptMessageDisplay=function (element){
	var msg=$(element).attr('promptMessage');
	
	if(element.type=== "text"&&element.id.endWith("selectized")){
			var elementNewId=element.id.substring(0,element.id.length-11);
			msg= $('#'+elementNewId).attr('promptMessage');
	}
	
	if(msg===undefined){
		return;
	}
	$(element).popover('dispose');
    $(element).attr('data-content',msg);
    $(element).popover(promptOption(msg));
    $(element).popover('show');
}

var escapeCssMeta=function( string ) {
			return string.replace( /([\\!"#$%&'()*+,./:;<=>?@\[\]^`{|}~])/g, "\\$1" );
		}

var findByName= function( name ) {
			return $( this.currentForm ).find( "[name='" + this.escapeCssMeta( name ) + "']" );
		}
		
var isInit=function(element){
	var elementValue="";
	var elementType=element.type;
	if(element.type=== "text"){
		if(element.id.endWith("selectized")){
			var elementNewId=element.id.substring(0,element.id.length-11)
			elementValue= $('#'+elementNewId).val();
		}else{
			elementValue= $(element).val();
		}
	}else if(element.type=== "radio"){
		var elementRChecked="input:radio[name="+element.name+"]:checked";
		elementValue=$(elementRChecked).val();
	}else if(element.type=== "checkbox"){
		//var elementCChecked="input:checkbox[name='"+element.name+"']:checked";
		var elementCChecked="input[name='"+element.name+"']:checked";
		if($(elementCChecked).length>0){
		elementValue=$(elementCChecked).length;
		}
		
	}
	return elementValue;
	
}

$.validator.setDefaults({
//ignore: ':hidden:not([class~=selectized]),:hidden > .selectized, .selectize-control .selectize-input input',
    errorPlacement: function ( error, element ) {
     $(element).popover('dispose');
            var message = $(error).text();
            if(message=== validator_pattern_message){
                message = validator_pattern[$(element).attr('data-pattern')]['message']
                if($(element).attr('data-message'))
                   message = $(element).attr('data-message')
            }
            $(element).attr('data-content',message)
            $(element).popover(popoverOption(message));
            if($(element).is(':focus')){
				$(element).popover('show');
            }
		},
    highlight: function ( element, errorClass, validClass ) {
        if($(element).parent().hasClass('selectize-input')) {
            $(element).parent().addClass('is-invalid form-control-danger')
        }
        else {
            $(element).addClass('is-invalid form-control-danger')
        }
    },
    
    unhighlight: function ( element, errorClass, validClass ) {
			$(element).popover('dispose');
            if($(element).parent().hasClass('selectize-input')) {
                $(element).parent().removeClass('is-invalid form-control-danger')
            }
            else {
                $(element).removeClass('is-invalid form-control-danger')
            }
				},
    
    onfocusin:function(element) {
             	if(($(element).hasClass("is-invalid"))||($(element).parent().hasClass('selectize-input')&&$(element).parent().hasClass('is-invalid'))){
             this.element(element);
             }else{
             	if(isInit(element)=== undefined||isInit(element)===""){
             //		if($(element).parent().hasClass('selectize-input')) {
            //    	$(element).parent().removeClass('is-invalid form-control-danger')
            //	}
            //	else {
            // 		$(element).removeClass('is-invalid form-control-danger')
            //	}
             		promptMessageDisplay(element);
             	}else{
               		this.element(element);
             	}
             
             }
             	
    },
    onfocusout: function(element) {
    	//this.element(element);
		$(element).popover('dispose');
	},
	onclick: function( element ) {
		this.element(element);

	},
	onkeyup:function(element,e) {
		// Avoid revalidate the field when pressing one of the following keys
			// Shift       => 16
			// Ctrl        => 17
			// Alt         => 18
			// Caps lock   => 20
			// End         => 35
			// Home        => 36
			// Left arrow  => 37
			// Up arrow    => 38
			// Right arrow => 39
			// Down arrow  => 40
			// Insert      => 45
			// Num lock    => 144
			// AltGr key   => 225
			var excludedKeys = [
				16, 17, 18, 20, 35, 36, 37,
				38, 39, 40, 45, 144, 225
			];
		if (event&&( (event.which === 9 && (isInit(element)=== undefined||isInit(element)==="")) || $.inArray( event.keyCode, excludedKeys ) !== -1 )) {
				return;
		}else{
			this.element(element);
		}
		if(($(element).hasClass("is-invalid"))||($(element).parent().hasClass('selectize-input')&&$(element).parent().hasClass('is-invalid'))){
             this.element(element);
             }else{
             	if(isInit(element)=== undefined||isInit(element)===""){
             		promptMessageDisplay(element);
             	}else{
             		
               		this.element(element);
             	}
             }
	}
});

$.validator.addMethod("pattern", function(value, element) {
  return this.optional( element ) || new RegExp(validator_pattern[$(element).attr('data-pattern')]['regx']).test( value );
}, validator_pattern_message);
