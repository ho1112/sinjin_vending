window.onload = () => {
	//protoType
	downloadButtonInit();

	/**
	 * 共通JS初期化を定義
	 */
	//menu.jsの初期化
	menuOnload();
	headerOnload();
};




//protoType
function downloadButtonInit(){
	let leng = $(".t-body tr").length;
	let td = $(".t-body td");

	let c = 0;
	let td1;
	for(let i =0; i< leng; i++){
		if(i == 0){
			td1 = td.eq(i+1).find('input').val();
		} else {
			td1 = td.eq(i*3+1).find('input').val();
		}

		if(i == 0){
			if(td1 == "こちら"){
				$(".t-body td:eq("+(i+2)+")").html(
						"<p class='button02_download' style='height:15px;'>" +
						"<a class='button02_download-In'" +
						"style='height:18px;' href='#'>" +
						"ダウンロード</a>" +
						"</p>");
			} else {
				$(".t-body td:eq("+(i+2)+")").html(
						//"<p class='button02_download' style='height:15px;>" +
						//"<a class='button02_download-In'" +
						//" style='opacity: 0.5; height:18px; cursor:Default;' href='#'>" +
						//"ダウンロード"+
						//"</a>" +
						//"</p>"
						);
			}

		} else {
			if(td1 == "こちら"){
				$(".t-body td:eq("+(i*3+2)+")").html(
						"<p class='button02_download' style='height:15px;'>" +
						"<a class='button02_download-In'" +
						"style='height:18px;' href='#'>" +
						"ダウンロード</a>" +
						"</p>");
			} else {
				$(".t-body td:eq("+(i*3+2)+")").html(
						//"<p class='button02_download' style='height:15px;'>" +
						//"<a class='button02_download-In'" +
						//" style='opacity: 0.5; height:18px; cursor:Default;' href='#'>" +
						//"ダウンロード"+
						//"</a>" +
						//"</p>"
						);
			}
		}


	}//end for
}
