//TPX010030.jsp
"use strict";
// Document Ready Event発生時の処理

$(function() {
	// 遷移情報の初期化
	// $("#hselectd").value = "";
	document.getElementById("hselected").value = "";

//	parent._alert = new parent.Function("alert(arguments[0]);");

	//
	// $("#formtpx010030").validate({
	// rules:{
	// input03:{
	// required:true,
	// CustomValidateRadio01:true
	// }
	// },
	// messages:{
	// radio01:{
	// required:'入力必須',
	// CustomValidateRadio01:'内容を確認の上、再度押下してください'
	// }
	// },
	//
	// //エラーメッセージの表示場所を設定
	// errorPlacement: function (err, elem) {
	//
	// err.appendTo($('p')); //p要素を指定
	// }
	// });
	//
	// jQuery.validator.addMethod(
	// "CustomValidateRadio01",
	// function(val,elem){
	// var targetselect = $('input[name="radio01"]');
	// if (targetselect.val === 'radio-01-b') {
	// // "銘柄" 指定の場合
	// if ($('#input03') === null || (isNaN($('#input03')))) {
	// return false;
	//
	// }
	//
	// }
	//
	// return true;
	//
	// },
	// 'このフィールドは必須です');
	// $("#formtpx010030").validate();

	// 一覧表示画面遷移ボタン
	$("#content-menu-a031")[0].addEventListener('click', function(e) {
		var yearstart = document.getElementById("year01");
		var monthstart = document.getElementById("month01");
		var daystart = document.getElementById("day01");

		var yearend = document.getElementById("year02");
		var monthend = document.getElementById("month02");
		var dayend = document.getElementById("day02");
		// 入力チェック

		// 銘柄・ISINチェック
		// 銘柄指定の場合、コード入力必須
		var input03check = function() {
			var targetselect = $('input[name="radio01"]');
			var targetcode = document.getElementById("input03").value;
			var coid = document.getElementById("coid")
			if (targetselect[1].checked) {
				// "銘柄" 指定の場合
				if (targetcode === null          // || (isNaN(targetcode.value))
						|| targetcode === "") {
					return false;

				}
			}

			return true;

		}
		if (!input03check()) {
//			parent._alert("銘柄は必須です");
			alert((coid.value === "" ? "銘柄コード" : "ISIN") + "を入力して下さい。");
			return;

		}


		// 銘柄指定の場合、文字種は、半角英数字
		var input03attributecheck = function() {
			var targetselect = $('input[name="radio01"]');
			var targetcode = document.getElementById("input03");
			if (targetselect[1].checked) {
				if (targetcode.value.match(/^[A-Za-z0-9]*$/)) {
					return true;

				}

				return false;

			}
			return true;

		}
		if (!input03attributecheck()) {
			alert((coid.value === "" ? "銘柄コード" : "ISIN") + "は半角英数字以外は入力できません。");
			return;

		}

		// 銘柄指定の場合、入力項目長が正しいこと
		var itemname = "";
		var input03lengthcheck = function() {
			var targetselect = $('input[name="radio01"]');
			var targetcode = document.getElementById("input03");
			var codeid = document.getElementById("coid");
			if (targetselect[1].checked) {
				// 銘柄コード選択
				if (codeid.value === "") {
					if (targetcode.value.length === 4 || targetcode.value.length === 5) {
						return true;
					} else {
						itemname = "銘柄";
						return false;
					}

				} else {
					// ISIN選択
					if (targetcode.value.length === 9 || targetcode.value.length === 12) {
						return true;
					} else {
						itemname = "ISIN";
						return false;
					}

				}

			}

			return true;

		}
		if (!input03lengthcheck()) {
			alert(itemname + "は" + (itemname === "銘柄" ? "4桁または5桁" : "9桁または11桁") + "で入力して下さい。");
			return;

		}

		// 期間チェック
		// 日付妥当性チェック
		var datecheck = function(year, month, day) {
			var datechecked;
			var datecompared;
			if (year === null || year === undefined || isNaN(year) || year.trim() === ""
				|| month === null || month === undefined || isNaN(month) || month.trim() === ""
				|| day === null || day === undefined || isNaN(day) || day.trim() === ""
				) {
				return false;
			}
			datechecked = year + "/" + ("0" + month).substr(-2, 2) + "/" + ("0" + day).substr(-2, 2);

			if(!datechecked.match(/^\d{4}\/\d{1,2}\/\d{1,2}$/)){
				return false;
			}

			datecompared = new Date(datechecked);
		    if(datecompared.getFullYear() !==  Number(datechecked.split("/")[0])
		        || datecompared.getMonth() !== Number(datechecked.split("/")[1]) - 1
		        || datecompared.getDate() !== Number(datechecked.split("/")[2])
		    ){
		        return false;
		    }

		    return true;
		}

		if (! datecheck(yearstart.value, monthstart.value, daystart.value)) {
			alert("指定日付に誤りが有ります。再度設定を行って下さい。");
			return;

		}

		if (! datecheck(yearend.value, monthend.value, dayend.value)) {
			alert("指定日付に誤りが有ります。再度設定を行って下さい。");
			return;

		}

		// 期間 開始日付・終了日付 大小チェック
		if (yearend.value + "/" + ("0" + monthend.value).substr(-2, 2) + "/" + ("0" + dayend.value).substr(-2, 2) <
			yearstart.value + "/" + ("0" + monthstart.value).substr(-2, 2) + "/" + ("0" + daystart.value).substr(-2, 2)) {
			alert("開始日は終了日と同日又はそれ以前を指定して下さい。");
			return;

		}

		// 事象のうちいずれか一つは、入力必須
		var inputc1check = function() {
			var c2301check = document.getElementById("c2301").checked;
			if (document.getElementById("c2301").checked || document.getElementById("c2302").checked || document.getElementById("c2303").checked
					|| document.getElementById("c2305").checked || document.getElementById("c2307").checked
					|| document.getElementById("c2308").checked || document.getElementById("c2309").checked
					|| document.getElementById("c2310").checked || document.getElementById("c2311").checked
					|| document.getElementById("c2313").checked || document.getElementById("c2314").checked
					|| document.getElementById("c2316").checked || document.getElementById("c2317").checked
					|| document.getElementById("c2318").checked || document.getElementById("c2319").checked
					|| document.getElementById("c2320").checked || document.getElementById("c2323").checked
					|| document.getElementById("c2324").checked || document.getElementById("c2325").checked
					|| document.getElementById("c2326").checked || document.getElementById("c2327").checked
					|| document.getElementById("c2304").checked || document.getElementById("c2315").checked
					|| document.getElementById("c2312").checked

			) {
				return true;

			}

			return false;

		}
		if (!inputc1check()) {
			alert("検索条件が設定されていません。条件を入力し、再操作して下さい。");
			return;

		}

		// 入力チェック 終了

		document.getElementById("hselected").value = "TPX010040";

		$('#formtpx010030').submit();

	}, false);

	var datepickerval = document.getElementById("datepicker").value;

	var numvaly;
	var numvalm;
	var numvald;

	var chrvaly;
	var chrvalm;
	var chrvald;

	if (datepickerval !== null && datepickerval !== undefined
			&& datepickerval.length == 10) {
		chrvaly = datepickerval.slice(6, 10);
		chrvalm = datepickerval.slice(0, 2);
		chrvald = datepickerval.slice(3, 5);

		numvaly = Number(chrvaly);
		numvalm = Number(chrvalm);
		numvald = Number(chrvald);

		// numvalm = Number(datepickerval.slice(4, 6));
		// numvald = Number(datepickerval.slice(6, 8));

		if (2011 <= numvaly && numvaly <= 2020 && 1 <= numvalm && numvalm <= 12
				&& 1 <= numvald && numvald <= 31) {
			$('#year01').val(chrvaly);
			$('#month01').val(chrvalm);
			$('#day01').val(chrvald);

			$('#year02').val(chrvaly);
			$('#month02').val(chrvalm);
			$('#day02').val(chrvald);

			// startyear.selectedIndex = 10;
			//
			// startmonth.selectedIndex = numvalm;
			// startday.selectedIndex = numvald;
			//
			// endyear.selectedIndex = 10;
			//
			// endmonth.selectedIndex = numvalm;
			// endday.selectedIndex = numvald;

		}

	}

});
