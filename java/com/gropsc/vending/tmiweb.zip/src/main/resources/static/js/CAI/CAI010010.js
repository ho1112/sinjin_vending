window.onload = () => {

	/**
	 * 共通JS初期化を定義
	 */
	//menu.jsの初期化
	menuOnload();
	headerOnload();
};




