function headerOnload() {
	//ヘッダーメニューイベント
	const headerMenu = document.querySelectorAll('.header-menu-item');
	headerMenu.forEach(item =>
		item.addEventListener('click', openHeaderMenu)
	);
}

/**
 *　//ヘッダーメニューイベント
 * @param event : クリックしたヘッダーメニュー
 * @returns　viewId :　画面ID　/ target : openタイプ
 */
function openHeaderMenu(event){
	let targetId = event.target.parentNode.id;
	//icon imageをクリックした場合
	if(event.target.nodeName === 'IMG') {
		targetId = event.target.parentNode.parentNode.id;
	}
	let viewId = "";
	let target = "_blank";
	switch(targetId) {
	case "header-menu-item-terms" :
		viewId = "CMN010130";
		break;
	case 'header-menu-item-how' :
		viewId = "CMN010140";
		break;
	case "header-menu-item-FAQ" :
		viewId = "CMN010850";
		break;
	case "header-menu-item-logout" :
		viewId = "Logout";
		target = "_top";
		break;
	default :
		return false;
		break;
	}

	headerPageRequest(viewId, target);
}

/**
 * ヘッダーメニュー画面遷移リクエスト
 * @param viewId
 * @param target
 * @returns　post送信form
 */
function headerPageRequest(viewId, target){
	const form = document.createElement('form');
	const objs = document.createElement('input');
	objs.setAttribute('type', 'hidden');

	//post送信
	form.appendChild(objs);
	form.setAttribute('method', 'post');
	form.setAttribute('action', viewId);
	form.setAttribute("target",target);
	document.body.appendChild(form);

	form.submit();
}