window.onload = () => {

	/**
	 * 共通JSファイル初期化を定義
	 */
	//menu.jsの初期化
	menuOnload();
	headerOnload();
}

/**
 * jquery-uiの下に配置すると、機能しない
 * このスクリプトでダウンロードファイルを設定が前提のため
 */

//field変数
let today;
let preMonth;
let oneMonth;
let possible = [];
let noDownDate = [];
$(function() {
	/* Server Time Test*/
	let st = srvTime();
	console.log("st :"+st);
	today = new Date(st);
	const japanOffset = 9;
	/* 基準時間は日本標準時 */
	let jp = today.getTime()+ (today.getTimezoneOffset() * 60000) + (japanOffset * 3600000);
	today.setTime(jp);
	/* 日本標準時変換完了*/
	/* Server Time Test End*/

	let mm0 = today.getMonth();
	let mm = today.getMonth()+1;
	let mm2 = today.getMonth()+2;
	let dd = today.getDate();
	let yy = today.getFullYear();

	if(dd<10) {
	    dd='0'+dd
	}
	if(mm0<10) {
	    mm0='0'+mm0
	}
	if(mm<10) {
	    mm='0'+mm
	}
	if(mm2<10) {
	    mm2='0'+mm2
	}

	today = yy+'-'+mm+'-'+dd;
	preMonth = yy+'-'+mm0+'-'+dd;
	oneMonth = yy+'-'+mm2+'-'+dd;

	//営業日10日前～1か月後まで
	possible = deleteWeeken(today,preMonth,oneMonth);
	//ダウンロードファイルがない日
	//***本番ではAPIでもらうので修正が必要***
	noDownDate = noDownloadDate();

}); //end 初期化

function test(){
	$.ajax({
		type: "post",
		url:"/getDate",
		dataType:"text",
		success : function(result){
			//$('#result').text(result);
			console.log(result);
		},
		error : function(a, b, c){
			alert(a + b + c);
		}
	});
}

//サーバー時間を取得
function srvTime() {
	let xmlHttp;
	if (window.XMLHttpRequest) {//
		xmlHttp = new XMLHttpRequest(); // IE 7.0, chrome, firefox
		xmlHttp.open('GET', window.location.href.toString(), false);
		xmlHttp.setRequestHeader("Content-Type", "text/html");
		xmlHttp.send('');
		return xmlHttp.getResponseHeader("Date");
	} else if (window.ActiveXObject) {
		xmlHttp = new ActiveXObject('Msxml2.XMLHTTP');
		xmlHttp.open('GET', window.location.href.toString(), false);
		xmlHttp.setRequestHeader("Content-Type", "text/html");
		xmlHttp.send('');
		return xmlHttp.getResponseHeader("Date");
	}
}

function deleteWeeken(today,preMonth,oneMonth){
	let date0 = new Date(preMonth);
    let date1 = new Date(today);
    let date2 = new Date(oneMonth);

    let count = 0;

    let pre = [];

    while(true) {
    	var temp_date = date1;
        if(count == 11) {
            break;
        } else {
            var tmp = temp_date.getDay();
            if(tmp == 0 || tmp == 6) {
                // 週末
            } else {
                // 平日
                pre.push(dateToFormat(temp_date));
                count++;
            }
            temp_date.setDate(date1.getDate() - 1);
        }
    }//end while

    count = 0;
    date1 = new Date(today);
    while(true) {
    	var temp_date = date1;
        if(temp_date.getTime() > date2.getTime()) {
            break;
        } else {
            var tmp = temp_date.getDay();
            if(tmp == 0 || tmp == 6) {
                // 週末
            } else {
                // 平日
                pre.push(dateToFormat(temp_date));
                count++;
            }
            temp_date.setDate(date1.getDate() + 1);
        }
    }//end while

    let uniq = pre.slice()
    .sort(function(a,b){
    	return a - b;
    })
    .reduce(function(a,b){
    	if (a.slice(-1)[0] !== b) a.push(b);
    	return a;
    },[]);

    return uniq;
}

function dateToFormat(date){

	let mm = date.getMonth()+1;
	let dd = date.getDate();
	let yy = date.getFullYear();

	if(dd<10) {
	    dd='0'+dd
	}
	if(mm<10) {
	    mm='0'+mm
	}

	return date = yy+mm+dd;

}

//***本番ではAPIでもらうので修正が必要***
function noDownloadDate(){
	let count = 0;
	let resultList = [];
	let noDD = []
	let temp = [];
	let mFlag = true;

	while(count < 4)
    {
       let number;
       number = parseInt(Math.random()*possible.length)+1
       for(i=0; i<count; i++)
          if(temp[i] == number) mFlag = false;
       if(mFlag)
       {
    	   temp[count] = number;
            count++;
       }
       mFlag = true;
   }

	for(i=0; i< temp.length; i++){
		noDD.push(possible[temp[i]]);
	}
	return noDD;
}

//jquery-ui.js #8788に宣言
function TPX010080(obj){
	let flag = obj.attr('selected-down');
	if(flag != 'selected' ){
		obj.css('background','lightblue');
		obj.attr('selected-down','selected');
	} else {
		obj.css('background','#FFFFFF');
		obj.attr('selected-down','none');
	}
}


//先月末選択ボタン
$("#chkid1").click(function(){
	let data= $(".data-file");
	let nowMonth = $(".ui-datepicker-today").attr('data-month');
	let preMonth = Number(nowMonth) -1;

	let result = 0;
	$(".data-file").each(function(index, element){
		if($(this).attr('data-month') == preMonth){
			let date = Number($(this).find('a').text());
			if(date >19){
				$(this).css('background','lightblue');
				$(this).attr('selected-down','selected');
			}
		}
	});
});

//今月末選択ボタン
$("#chkid2").click(function(){
	let data= $(".data-file");
	let nowMonth = $(".ui-datepicker-today").attr('data-month');

	let result = 0;
	$(".data-file").each(function(index, element){
		if($(this).attr('data-month') == nowMonth){
			let date = Number($(this).find('a').text());
			if(date >19){
				$(this).css('background','lightblue');
				$(this).attr('selected-down','selected');
			}
		}
	});
});

//全て選択ボタン
$("#chkid3").click(function(){
	$(".data-file").css('background','lightblue');
	$(".data-file").attr('selected-down','selected');
});

//全てクリアボタン
$("#chkid4").click(function(){
	$(".data-file").css('background','#FFFFFF');
	$(".data-file").attr('selected-down','none');
});

//ダウンロードボタン
$(".button01_red-In").click(function(){
	let data= $(".data-file");
	let result = 0;
	$(".data-file").each(function(index, element){
		let sel;
		if($(this).attr('selected-down') == null){

		} else {
			sel = $(this).attr('selected-down');
			if(sel == 'selected'){
				result++;
			}else {

			}
		}
	});
	//1件もない場合
	if(result > 0){
		//alert('download start');
	} else {
		alert('カレンダーの日付が選択されていません。');
	}
});























