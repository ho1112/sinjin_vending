//TPX010030.jsp
"use strict";

// Document Ready Event発生時の処理
$(function() {
	// 遷移情報の初期化
	// $("#hselectd").value = "";
	document.getElementById("hselected").value = "";
//	var linesperpage = document.getElementById("linesperpage");
	var linesperpage = $("#linesperpage");

	// dropdownlist currentidsの設定
	var lineschangedf = function() {
		alert("changed");
	}
	var lineschanged
	 = function(e) {
		var currentids = document.getElementById("currentids");
		var tpx010040count = document.getElementById("tpx010040count");
//		var linesperpage = document.getElementById("linesperpage");
		var count;
		var lines;
		var upper = 0;
		var start = 0;
		var option;
		var text;

		// option要素を削除
		while (0 < currentids.childNodes.length) {
			currentids.removeChild(currentids.childNodes[0]);
		}

		if (tpx010040count !== null && tpx010040count !== undefined) {
			count = tpx010040count.value;

			if (count !== null && count !== undefined) {
				if (linesperpage.value !== null && linesperpage.value !== undefined && (! isNaN(linesperpage.value))) {
					lines = Number(linesperpage.value);

				} else {
					lines = 20;
				}
				while (upper < count) {
					// option要素を生成
					start = upper + 1;
					upper = Math.min((upper + lines), count);
					option = document.createElement('option');
					text = document.createTextNode((start + '') + '-'
							+ (upper + ''));
					option.appendChild(text);

					// option要素を追加
					currentids.appendChild(option);

				}
			}

		}
	}
	linesperpage.on('change', lineschangedf);
//	linesperpage.addEventListener('change', lineschanged	, false);

	lineschanged();

	// 一覧表示画面遷移ボタン
	$("#content-menu-a032")[0].addEventListener('click', function(e) {
		document.getElementById("hselected").value = "TPX010030";

		var url = $('#formtpx010010').attr('action');
		url = url.slice(0, url.lastIndexOf("/"));

		$('#formtpx010010').attr('action', url + "/TPX010030");

		$('#formtpx010010').submit();

	}, false);

});
