function menuOnload() {
	//メニューボタンイベント
	const menu = document.querySelectorAll('.menu-item').forEach(item =>
		item.addEventListener('click', openMenu)
	);
}

//メニュー画面遷移イベント
function openMenu(event) {
	let targetId = event.target.parentNode.id;
	//icon imageをクリックした場合
	if(event.target.nodeName === 'IMG') {
		targetId = event.target.parentNode.parentNode.id;
	}
	let viewId = "";
	switch(targetId) {
	case "TOP_JP" :
		viewId = "TOP010010";
		break;
	case "TOP_EN" :
		viewId = "TOP020010";
		break;
	case "TPX" :
		viewId = "TPX010010";
		break;
	case "CAI" :
		viewId = "CAI010010";
		break;
	case "TDN" :
		viewId = "TDN010010";
		break;
	case "TOF" :
		viewId = "TOF010010";
		break;
	case "SGK" :
		viewId = "SGK010010";
		break;
	default :
		return false;
		break;
	}

	postPageRequest(viewId);
}

/**
 * viewIDをconstにして
 * directにpageRequest（）をすることも考えておくこと。
 */
//画面遷移リクエスト
function postPageRequest(viewId){
	const form = document.createElement('form');
	const objs = document.createElement('input');
	objs.setAttribute('type', 'hidden');

	//post送信
	form.appendChild(objs);
	form.setAttribute('method', 'post');
	form.setAttribute('action', viewId);
	//form.setAttribute("target","_blank");
	document.body.appendChild(form);

	form.submit();
}













