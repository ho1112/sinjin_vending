let SELECTABLE_START_DATE;
let SELECTABLE_LAST_DATE;
let TODAY;
window.onload = () => {
	/**
	 * 共通JSファイル初期化を定義
	 */
	//menu.jsの初期化
	menuOnload();
	headerOnload();
	//calendarの初期化
	getServerTime();
	//calendarの年、月を選択するとselect optionを更新
	document.querySelectorAll('.selectableYear').forEach(item =>
		item.addEventListener('change', changeDate)
	);
	document.querySelectorAll('.selectableMonth').forEach(item =>
		item.addEventListener('change', changeDate)
	);

	document.querySelector('#tpx-menu-3-search').addEventListener('click', topixSearch);
}

/**
 *　server時間を持ってきてカレンダーを初期化する
 * 今日から2年前～翌年12月31日まで
 */
function getServerTime() {
	//serverから時間を取ってくる
	const httpRequest = new XMLHttpRequest();
	httpRequest.open("POST", "/getDate");
	httpRequest.onreadystatechange = function() {
		if(httpRequest.readyState == 1 || httpRequest.readyState == 2
		|| httpRequest.readyState ==3 ){　//呼び出し中
			//Loading中の作業
			//console.log("loading...");
		}else if(httpRequest.readyState == 4 && httpRequest.status == 200){　//正常の場合
			const serverTime = httpRequest.responseText.split(" "); //例） Tue,Mar,24,11:48:53,JST,2020
			TODAY = new Date(`${serverTime[1]} ${serverTime[2]},${serverTime[5]} ${serverTime[3]}`);//Mar 24,2020 11:48:53
            /* selectに設定*/
            /* カレンダー範囲定数　2年前 ～翌年末迄*/
            SELECTABLE_START_DATE = new Date(TODAY.getFullYear()-2,TODAY.getMonth()+1,TODAY.getDate());
            SELECTABLE_LAST_DATE　= new Date(TODAY.getFullYear()+1,11,31);

            /*年初期化*/
            const year1 = document.querySelector('#year01');
            const year2 = document.querySelector('#year02');
            const selectableYear = [SELECTABLE_START_DATE.getFullYear(), TODAY.getFullYear()-1, TODAY.getFullYear(), SELECTABLE_LAST_DATE.getFullYear()];
            selectableYear.forEach(function(element,key) {
        		year1[key] = new Option(element,element, key===2? true:false, key===2? true:false);
        		year2[key] = new Option(element,element, key===2? true:false, key===2? true:false);
        	});

            /*月初期化*/
            const month1 = document.querySelector('#month01');
            const month2 = document.querySelector('#month02');
            for(let i = 1;i<13;i++){
            	month1[i-1] = new Option(i,i, i===TODAY.getMonth()+1? true:false, i===TODAY.getMonth()+1? true:false);
            	month2[i-1] = new Option(i,i, i===TODAY.getMonth()+1? true:false, i===TODAY.getMonth()+1? true:false);
            }

            /*日初期化*/
            const day1 = document.querySelector('#day01');
            const day2 = document.querySelector('#day02');
            const lastDay = getLastDay(TODAY.getFullYear(),TODAY.getMonth());
            for(let i = 1;i<lastDay+1;i++){
            	day1[i-1] = new Option(i,i, i===TODAY.getDate? true:false, i===TODAY.getDate()? true:false);
            	day2[i-1] = new Option(i,i, i===TODAY.getDate? true:false, i===TODAY.getDate()? true:false);
            }

            /* datepicker 初期化 jQuery libraryなのでjQuery文法必須*/
            $('#datepicker').datepicker( "option", "maxDate", SELECTABLE_LAST_DATE);
            $('#datepicker02').datepicker( "option", "maxDate", SELECTABLE_LAST_DATE);
            document.querySelector('#ui-datepicker-div').style.display = "none";

        }else{ //エラー
        	console.log("Server Connect Error");
        }
    }
	//serverへrequestを送信
	httpRequest.send();
}

//Date, targetNumber
function changeDate(event){
	let year;
	let month;
	let day;
	let targetNumber;

	if(event.target.id === 'year01' || event.target.id === 'month01'){
		targetNumber = "01";
	}else if(event.target.id === 'year02' || event.target.id === 'month02'){
		targetNumber = "02";
	}else{
		targetNumber = "01";
	}

	if(targetNumber === "01"){
		year = document.querySelector("#year01").value;
		month = document.querySelector("#month01").value;
		day = document.querySelector("#day01").value;
	}else{
		year = document.querySelector("#year02").value;
		month = document.querySelector("#month02").value;
		day = document.querySelector("#day02").value;
	}

	putSelectedDate(year, month, day, targetNumber);
}

/**
 * datepickerアイコンから選択された日付をプルダウンに設定する。
 * @param txt:選択された日付, inst:選択されたdatepicker Object情報
 */
function putSelectedDatepicker(txt, inst){
	const inputDate = txt.split('/');
	const year = inputDate[0];
	const month = inputDate[1] < 10? inputDate[1].substring(1,2):inputDate[1];
	const day = inputDate[2] < 10? inputDate[2].substring(1,2):inputDate[2];

	let targetNumber;
	if(inst.id === "datepicker"){
		targetNumber = "01";
	}else if(inst.id === "datepicker02"){
		targetNumber = "02";
	}else{
		targetNumber = "01";
	}

	putSelectedDate(year, month, day, targetNumber);
}

function putSelectedDate(year, month, day, targetNumber){
	/***************年***************/
	const selectableYear = [SELECTABLE_START_DATE.getFullYear(), TODAY.getFullYear()-1, TODAY.getFullYear(), SELECTABLE_LAST_DATE.getFullYear()];
    const targetYear = document.querySelector("#year"+targetNumber);
	selectableYear.forEach(function(element,key) {
		targetYear[key] = new Option(element,element, year == element? true:false, year == element? true:false);
	});
	/***************月***************/
    const targetMonth = document.querySelector("#month"+targetNumber);
    //既存月削除
    while(targetMonth.firstChild) {
    	targetMonth.firstChild.remove();
    }
    //2年前かチェック
	if(year == SELECTABLE_START_DATE.getFullYear()){
		//選択範囲の月を設定
		let minMonth = TODAY.getMonth()+1;
	    for(let i = 1;minMonth<13;i++){
	    	targetMonth[i-1] = new Option(minMonth,minMonth, minMonth == month?true:false, minMonth == month?true:false);
	    	minMonth++;
	    }
	}else{
		//選択範囲の月を設定
	    for(let i = 1;i<13;i++){
	    	targetMonth[i-1] = new Option(i,i, i == month?true:false, i == month?true:false);
	    }
	}
	/***************日***************/
	const targetDay = document.querySelector("#day"+targetNumber);
	//既存日削除
	while(targetDay.firstChild) {
		targetDay.firstChild.remove();
	}
    const lastDay = getLastDay(year, Number(month)-1);
    for(let i = 1; i < lastDay+1; i++){
    	targetDay[i-1] = new Option(i,i, i == day?true:false, i == day? true:false);
    }
}

/**
 * 日付情報を基で該当する月の最後の日を返却する。
 * @param year:年, month：月
 * @return 引数の月の末日
 */
function getLastDay(year, month) {
	  const lastDay = new Date(year, month + 1);
	  lastDay.setDate(0);
	  return lastDay.getDate();
}

/**
 * 検索条件のvalidationおよび一覧表示のリクエスト
 * @param 検索条件
 * @returns 一覧表示リクエスト
 */
function topixSearch(){
	//validation
	/* code here */

	/* 期間 */
	const year01 = document.querySelector("#year01").value;
	const month01 = document.querySelector("#month01").value.length < 2? "0"+document.querySelector("#month01").value:document.querySelector("#month01").value;
	const day01 = document.querySelector("#day01").value.length < 2? "0"+document.querySelector("#day01").value:document.querySelector("#day01").value;;
	const year02 = document.querySelector("#year02").value;
	const month02 = document.querySelector("#month02").value.length < 2? "0"+document.querySelector("#month02").value:document.querySelector("#month02").value;
	const day02 = document.querySelector("#day02").value.length < 2? "0"+document.querySelector("#day02").value:document.querySelector("#day02").value;;

	const dateValue01 = Number(year01+month01+day01);
	const dateValue02 = Number(year02+month02+day02);
	if(dateValue01 > dateValue02){
		alert("日付をチェック");
		return false;
	}
	/*　期間完了 */

	/*　end validation*/

	//検索リクエスト
	const viewId = "TPX010040";
	const form = document.createElement('form');
	const objs = document.createElement('input');
	objs.setAttribute('type', 'hidden');

	//post送信
	form.appendChild(objs);
	form.setAttribute('method', 'post');
	form.setAttribute('action', viewId);
	//form.setAttribute("target","_blank");
	document.body.appendChild(form);

	form.submit();
}


//以下は改善前のソース(上記のソースに代替)
/**
 * 年プルダウンを変更イベント->月プルダウン初期化
 * @param 選択された年プルダウン
 */
function changeYear(event) {
	let eventTarget;
	let tempMonth;
	if(event === 'datepicker'){
		eventTarget = document.querySelector("#year01");
		tempMonth = Number(document.querySelector("#month01").value);
	}else if(event === 'datepicker02'){
		eventTarget = document.querySelector("#year02");
		tempMonth = Number(document.querySelector("#month02").value);
	}else{
		eventTarget = event.target;
	}

	const seletedYearIndex = eventTarget.selectedIndex;
	const selectedYearValue = eventTarget[seletedYearIndex].value;
	let targetMonth;
	if(eventTarget.id === 'year01'){
		targetMonth = document.querySelector('#month01');
	}else{
		targetMonth = document.querySelector('#month02');
	}

	//月削除
	while(targetMonth.firstChild) {
		targetMonth.firstChild.remove();
	}
	//2年前かチェック
	if(selectedYearValue == SELECTABLE_START_DATE.getFullYear()){
		//選択範囲の月を設定
		let month = TODAY.getMonth()+1;
	    for(let i = 1;month<13;i++){
	    	targetMonth[i-1] = new Option(month,month, month === tempMonth?true:false, month === tempMonth?true:false);
	    	month++;
	    }
	}else{
		//選択範囲の月を設定
	    for(let i = 1;i<13;i++){
	    	targetMonth[i-1] = new Option(i,i, i === tempMonth?true:false, i === tempMonth?true:false);
	    }
	}

	//年を変えると、月の情報も更新
	changeMonth(eventTarget);
}

/**
 * 月プルダウンを変更イベント->日プルダウン初期化
 * @param 選択された月プルダウン(年プルダウン)
 */
function changeMonth(eventTarget) {
	if(eventTarget.id === 'year01' || eventTarget.id === 'year02'){
	}else {
		eventTarget = eventTarget.target;
	}

	let seletedYearIndex;
	let selectedYearValue;
	let seletedMonthIndex;
	let selectedMonthValue;
	let targetDay;
	if(eventTarget.id === 'year01' || eventTarget.id === 'month01' ){
		seletedYearIndex = document.querySelector('#year01').selectedIndex;
		selectedYearValue = document.querySelector('#year01')[seletedYearIndex].value;
		seletedMonthIndex = document.querySelector('#month01').selectedIndex;
		selectedMonthValue = document.querySelector('#month01')[seletedMonthIndex].value;
		targetDay = document.querySelector('#day01');
	}else if(eventTarget.id === 'year02' || eventTarget.id === 'month02'){
		seletedYearIndex = document.querySelector('#year02').selectedIndex;
		selectedYearValue = document.querySelector('#year02')[seletedYearIndex].value;
		seletedMonthIndex = document.querySelector('#month02').selectedIndex;
		selectedMonthValue = document.querySelector('#month02')[seletedMonthIndex].value;
		targetDay = document.querySelector('#day02');
	}

	const lastDay = getLastDay(selectedYearValue, selectedMonthValue-1);
	//既存の日を削除
	while(targetDay.firstChild) {
		targetDay.firstChild.remove();
	}

	//2年前、月一致の場合
	if(SELECTABLE_START_DATE.getFullYear() == selectedYearValue && SELECTABLE_START_DATE.getMonth() == selectedMonthValue){
		//Day プルダウンを埋める
		let date = TODAY.getDate();
	    for(let i = 1;date<lastDay+1;i++){
	    	targetDay[i-1] = new Option(date,date);
	    	date++;
	    }
	//2年前ではない場合
	}else{
		//Day プルダウンを埋める
		for(let i = 1;i<lastDay+1;i++){
			targetDay[i-1] = new Option(i,i);
		}
	}

}











