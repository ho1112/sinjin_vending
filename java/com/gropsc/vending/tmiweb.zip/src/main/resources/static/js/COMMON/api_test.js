window.onload = () => {
	console.log(api);
	//let json = JSON.parse(api);
	console.log(api[0].data1);
	console.log(api[0].data2[2]);
}