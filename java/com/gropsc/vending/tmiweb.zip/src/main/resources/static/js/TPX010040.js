//TPX010030.jsp
"use strict";

let maxPage = 0;
let maxPageVal;
let form = $("#formtpx010040return");
const TPX40 = "TPX010040";
const TPX50 = "TPX010050";
// Document Ready Event発生時の処理
$(function() {
	// 遷移情報の初期化
	// $("#hselectd").value = "";
	document.getElementById("hselected").value = "";
//	var linesperpage = document.getElementById("linesperpage");
	var linesperpage = $("#linesperpage");
	var hlinesperpage = document.getElementById("hlinesperpage");
	var contentmenu = $("#content-menu-a032")[0];

	var thissubmit = function(lasturl) {
		document.getElementById("hselected").value = lasturl; // "TPX010030";

		var url = $('#formtpx010010').attr('action');
		url = url.slice(0, url.lastIndexOf("/"));
		$('#formtpx010010').attr('action', url + "/" + lasturl);
		$('#formtpx010010').submit();

	}

	// 一覧表示画面遷移ボタン
	// $("#content-menu-a032")[0].addEventListener('click', function() {
	contentmenu.addEventListener('click', function() {
		thissubmit("TPX010030");
	}, false);

	// dropdownlist currentidsの設定
	var createcurrentids = function(issubmit) {
		var currentids = document.getElementById("currentids");
		var tpx010040count = document.getElementById("tpx010040count");
		var count;
		var lines;
		var upper = 0;
		var start = 0;
		var option;
		var text;


		// option要素を削除
		while (0 < currentids.childNodes.length) {
			currentids.removeChild(currentids.childNodes[0]);
		}

		if (tpx010040count !== null && tpx010040count !== undefined) {
			count = tpx010040count.value;

			if (count !== null && count !== undefined) {
				if (issubmit && linesperpage.value !== null
						&& linesperpage.value !== undefined
						&& (!isNaN(linesperpage.value))) {
					lines = Number(linesperpage.value);

				} else {
					lines = Number(hlinesperpage.value);
				}
				let page = 1;
				while (upper < count) {
					// option要素を生成
					start = upper + 1;
					upper = Math.min((upper + lines), count);
					option = document.createElement('option');
					text = document.createTextNode((start + '') + '-'
							+ (upper + ''));
					document.creact
					option.appendChild(text);
					//20/01/30 value 追加
					option.value = page;
					page++;

					// option要素を追加
					currentids.appendChild(option);

				}
				maxPage = page-1;

			}

			if (issubmit) {
				thissubmit("TPX010030/init");

			}

		}
	}

	//20/01/30 表示行数プルダウン初期表示設定
	let selectedBox = $("#lpp").val();
	$('#linesperpage option[value='+ selectedBox +']').attr('selected', true);

	/*

	linesperpage.addEventListener('change', function() {
		alert("linesperpage onchange");

		createcurrentids(true);

	}, false);*/

	linesperpage.value = hlinesperpage.value;
	createcurrentids(false);


	//20/01/30 ページプルダウン設定
	selectedPageInit();

	//20/02/03 ページbutton, sort動作制御(色、クリック、アイコン)
	maxPageInit();

	//20/02/06 form action初期化
	//form.attr("action", "/TPX010040");
	form.attr("target","_top");
	$("#index").val('');

	//20/02/06 データ件数による活性・非活性対応
	if($("#dataMessage").attr('dataCount') == "0"){
		zeroDataSettiong();
	}


}); //end 初期化


//2020/01/29 表示行数プルダウン変更イベント
$("#linesperpage").change(function(){
	//20/02/06 form action初期化
	pathSetting(TPX40);
	form.attr("target","_top");

	let maxCount = $("#tpx010040count").val();

	let selectedLine =linesperpage.options[linesperpage.selectedIndex].text

	//currentpage初期化
	$("#currentpage").val('');

	//再検索を行う
	$("#formtpx010040return").submit();
});

//2020/01/30 ページプルダウン変更イベント
$("#currentids").change(function(){
	//20/02/06 form action初期化
	pathSetting(TPX40);
	form.attr("target","_top");
	$("#index").val('');

	let selectedPage = $("#currentids option:selected").val();
	$("#currentpage").val(selectedPage);
	//再検索を行う
	$("#formtpx010040return").submit();

});

//20/01/30 ページプルダウン表示設定
function selectedPageInit() {
	let selectedPage = $("#currentpage").val();
	$('#currentids option[value='+ selectedPage +']').attr('selected', true);
}

//20/01/30 ページボタンクリック
$(".movePageButton").click(function(){
	//20/02/06 form action初期化
	pathSetting(TPX40);
	form.attr("target","_top");
	$("#index").val('');

	let id = $(this).attr('id');
	switch(id) {
	case 'firstPage' :
		$("#currentpage").val("1");
		$("#formtpx010040return").submit();
		break;
	case 'previousPage' :
		if($("#currentpage").val() != "1"){
			$("#currentpage").val(Number($("#currentpage").val()) -1);
			$("#formtpx010040return").submit();
		}
		break;
	case 'nextPage' :
		if($("#currentpage").val() != maxPage){
			$("#currentpage").val(Number($("#currentpage").val()) +1);
			$("#formtpx010040return").submit();
		}
		break;
	case 'lastPage' :
		$("#currentpage").val(maxPage);
		$("#formtpx010040return").submit();
		break;
	}

});

//20/01/30 scrollbar ▲ページ上部に移動
$(".move-to-top").click(function(){
	let scrollTop = $(".tableTop tbody").scrollTop();
	$(".tableTop tbody").scrollTop(0);
})

//20/01/30 一覧画面再整列
$(".lnk0").click(function(){
	//20/02/06 form action初期化
	pathSetting(TPX40);
	form.attr("target","_top");
	$("#index").val('');

	//ソートをtoggle
	let sort = $("#sort").val();
	if(sort == 'sort-01'){
		$("#sort").val('sort-02');
	} else {
		$("#sort").val('sort-01');
	}

	switch($(this).attr('value')){
	case "指数修正日" :
		$("#radioorder").val("radioorder-01");
		//$("#display").val("display-01");
		$("#sortView").val("sortView-01");
		break;
	case "情報登録日" :
		$("#radioorder").val("radioorder-01");
		//$("#display").val("display-02");
		$("#sortView").val("sortView-02");
		break;
	case "銘柄コード" :
	$("#radioorder").val("radioorder-03");
	$("#sortView").val("sortView-03");
		break;
	}
	$("#currentpage").val('1');
	$("#proc").val('return');
	$("#formtpx010040return").submit();


	//再整列(再検索)
});

//20/02/03 pege button(<a>) disable control
function maxPageInit(){
	let currentpage = $("#currentpage").val();
	if(currentpage == maxPage){
		$("#lastPage").css('opacity','0.5');
		$("#nextPage").css('opacity','0.5');
	}
}

//20/02/04 詳細ボタンイベント(画面遷移)
$(".button02_detail-In").click(function(){
	let fid = $(this).attr('id');
	let id = fid.replace('index','');
	$("#index").val(id);

	pathSetting(TPX50);

	let index = $("#index").val();

	form.attr("method", "post");
	form.attr("index",id);
	form.attr("target",index);
	//form.attr("action", "/TPX010050");

	//英語版遷移
	let td = $("#t-body td");
	let tdId = td.eq(19).find('a').attr('id');
	if(fid == tdId){
		$("#language").val("en");
	}else {
		$("#language").val("ja");
	}

	//let lan = $("#language").val();
	//let url = $("#formtpx010040return").attr('action')+'?language='+lan+'&index='+index;

	$("#formtpx010040return").submit();
	//window.open(url,'_blank');

	//location.href = "/ph2/TPX010050?index="+id+"?form="+form;
});


// 20/02/06 local<->heroku urlSetting
// lasturl : "TPX40" or "TPX50"
function pathSetting(lasturl){
	let url = form.attr('action'); // local : /ph2/TPX010040, heroku : /TPX010040
	url = url.slice(0, url.lastIndexOf("/"));   // local : /ph2, heroku : '' ?
	form.attr('action', url +"/" + lasturl);	// local : /ph2/TPX0100X0, heroku : /TPX0100X0
}

//20/02/06 データ件数による活性・非活性対応
function zeroDataSettiong(){
	$("#linesperpage").attr('disabled','disabled');
	$("#linesperpage").find('option').remove();
	$("#linesperpage").css('cursor','Default');

	$("#currentids").attr('disabled','disabled');
	$("#currentids").css('cursor','Default');

	$(".next").find('a').attr('id','disabled');
	$(".next").find('a').css('opacity','0.5');
	$(".next").find('a').css('cursor','Default');

	$(".lnk0").find('br').remove();
	$(".lnk0").contents().unwrap().wrap( '<p></p>' );
	$(".lnk0").css('cursor','Default');

	$(".button01_red-In").css('opacity','0.5');
	$(".button01_red-In").css('cursor','Default');

	$(".move-to-top").find('span').css('cursor','Default');



}





