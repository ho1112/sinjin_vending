//redirecthello.jsp
"use strict";
// Document Ready Event発生時の処理
$(function(){
	$('#formred010010').submit();

});
