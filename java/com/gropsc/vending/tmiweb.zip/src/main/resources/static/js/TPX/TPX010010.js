window.onload = () => {

	/**
	 * 共通JSファイル初期化を定義
	 */
	//menu.jsの初期化
	menuOnload();
	headerOnload();
}








