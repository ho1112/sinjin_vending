//TDN010010.html

$(function () {
    $("button.addfield.bt01").click(function () {
        $("dl.code-list.code.cd01").append("<dd class='code-or' style='margin-bottom: 0px;'>OR</dd><dd class='code-field' style='margin-bottom: 0px;'><input class='text-field' type='text' name='textfieldName2' size='20' /></dd>");
    });
});

$(function () {
    $("button.addfield.bt02").click(function () {
        $("dl.code-list.code.cd02").append("<dd class='code-or' style='margin-bottom: 0px;'>OR</dd><dd class='code-field' style='margin-bottom: 0px;'><input class='text-field' type='text' name='textfieldName2' size='40'/></dd>");
    });
});

$(function () {
    $("button.addfield.bt03").click(function () {
        $("dl.code-list.code.cd03").append("<dd class='code-or' style='margin-bottom: 0px;'>OR</dd><dd class='code-field' style='margin-bottom: 0px;'><input class='text-field' type='text' name='textfieldName2' size='40' /></dd>");
    });
});
